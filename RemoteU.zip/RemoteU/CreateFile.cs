﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;//add

namespace RemoteU
{
    class CreateFile
    {
       
        public static void CR()
        {
            string path = Directory.GetCurrentDirectory();

            //string path = @"c:\temp\session.bat";

            try
            {
                // Create the file, or overwrite if the file exists.
                using (FileStream fs = File.Create(path+"\\session.bat"))
                 {
                    byte[] info = new UTF8Encoding(true).GetBytes(@"cmd.exe /C FOR /F ""tokens=2,3 skip=1"" %%A IN ('query session /SERVER:" + Form1.GName+ "') DO @echo %%A %%B > users.txt");
                    
                    // Add some information to the file.
                    fs.Write(info, 0, info.Length);
                }

                // Open the stream and read it back.
                using (StreamReader sr = File.OpenText(path + "\\session.bat"))
                {
                    string s = "";
                    while ((s = sr.ReadLine()) != null)
                    {
                        Console.WriteLine(s);
                    }
                }
            }

            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }
        }
    }
}


    




