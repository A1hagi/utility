﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;//add
using System.Windows.Forms;

using System.DirectoryServices;
using System.DirectoryServices.AccountManagement;
using System.DirectoryServices.Protocols;
using System.Diagnostics;
using System.Threading;

namespace RemoteU

{
    public partial class Form1 : Form
    {

        string path = Directory.GetCurrentDirectory(); //текущий каталог

        public Form1()

        
        {

            InitializeComponent();
        }
        public static string GName = ".";                     //server

        


        private void Form1_Load(object sender, EventArgs e)
        {

            //****************удаление старых файлов
            
            FileInfo fileUsr = new FileInfo(path + @"\users.txt");
            if (fileUsr.Exists)
            {
                fileUsr.Delete();
                // альтернатива с помощью класса File
                // File.Delete(path);
            }


            FileInfo fileBat = new FileInfo(path + "\\session.bat");
            if (fileBat.Exists)
            {
                fileBat.Delete();
                // альтернатива с помощью класса File
                // File.Delete(path);
            }

            //****************удаление старых файлов

            dataGridView1.Visible = false;                  //скрыть DataGrid
                                                            //MessageBox.Show(path);глянуть текущий путь


            //чтение списка серверов------------------------------------------
            using (StreamReader r = new StreamReader(path + "\\" + "srv.dat", Encoding.Default))
                while (!r.EndOfStream)
                    comboBox1.Items.Add(r.ReadLine());
            //чтение списка серверов------------------------------------------




            



        }

        private void toolTip1_Popup(object sender, PopupEventArgs e)
        {

        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (comboBox1.Text == "")

            {
                MessageBox.Show("Заполните список");
            }

            else

            {

                GName = comboBox1.Text;  //server
                string cb = comboBox1.Text.ToString();
                //MessageBox.Show(cb);
                new CreateFile();
                CreateFile.CR();
                dataGridView1.Visible = true;

                if (File.Exists(path + @"\users.txt"))
                {
                    System.IO.File.Delete(path + @"\users.txt");
                }


                //**************запуск bat для заполнения user.txt
                System.Diagnostics.Process aProcess = new Process();
                
                aProcess = Process.Start(path + "\\session.bat");
                aProcess.WaitForExit(500);
                
                //*******ждем 50 енотов
                Thread.Sleep(500);


                {
                    string[] dataString = File.ReadAllLines(path + @"\users.txt");
                    DataTable dt = new DataTable();
                    dt.Columns.Add("Номер п/п");
                    dt.Columns.Add("UserName");
                    dt.Columns.Add("ID");
                    dt.Columns.Add("DisplayName");
                    int count = 1;
                    string[] ss;

                    foreach (string s in dataString)

                        if ((((s.Remove(s.IndexOf(' '), s.Length - s.IndexOf(' '))).Length>2)) 
                            & (((s.Remove(s.IndexOf(' '), s.Length - s.IndexOf(' '))).Length > 3)))


                            //отсеивать отключенные сессии

                        {

                        //MessageBox.Show(s.Remove(s.IndexOf(' '), s.Length - s.IndexOf(' '))).ToString();

                            (s.Substring(0, s.LastIndexOf(' '))).ToString();

                        ss = s.Split(' ');

                                dt.Rows.Add(count, ss[0], ss[1]);
                                count++;

                              
                        }
                            dataGridView1.DataSource = dt;
                            dataGridView1.Columns[0].Width = 20;
                            dataGridView1.Columns[1].Width = 50;
                            dataGridView1.Columns[2].Width = 20;
                            //MessageBox.Show(dt.Rows[count].ToString());
                            dataGridView1.ReadOnly = true; //блокировка редактирования
                            dataGridView1.Columns[0].SortMode = DataGridViewColumnSortMode.NotSortable;
                            dataGridView1.Columns[1].SortMode = DataGridViewColumnSortMode.NotSortable;
                            dataGridView1.Columns[2].SortMode = DataGridViewColumnSortMode.NotSortable;
                            dataGridView1.Columns[3].SortMode = DataGridViewColumnSortMode.NotSortable;

                    


                }

                //****************удаление старых файлов

                FileInfo fileUsr = new FileInfo(path + @"\users.txt");
                if (fileUsr.Exists)
                {
                    fileUsr.Delete();
                    // альтернатива с помощью класса File
                    // File.Delete(path);
                }


                FileInfo fileBat = new FileInfo(path + "\\session.bat");
                if (fileBat.Exists)
                {
                    fileBat.Delete();
                    // альтернатива с помощью класса File
                    // File.Delete(path);
                }

                //****************удаление старых файлов

                aProcess.Close();
            }
            
            //Thread.Sleep(50);
            int rCount = dataGridView1.RowCount;
            //MessageBox.Show(rCount.ToString());
            // dataGridView1.Rows.RemoveAt(rCount-1);//----------------------------------- СНЯТЬ КОММЕНТЫ
            

            //*******заполнеие из AD DisplayName
            foreach (DataGridViewRow r in dataGridView1.Rows)
            {
               string to = dataGridView1.Rows[r.Index].Cells[1].Value.ToString();
               // MessageBox.Show (to);


                string username = Environment.UserName;
                DirectorySearcher mySearcher = new DirectorySearcher();
                mySearcher.Filter = ("(&(objectclass=user)(samaccountname=" + to + "))");
                SearchResult result = mySearcher.FindOne();
                if (result != null)
                {
                    this.Text += " - " + result.Properties["displayname"][0].ToString();
                   // MessageBox.Show(result.Properties["displayname"][0].ToString());  Показать DispalyName
                    dataGridView1.Rows[r.Index].Cells[3].Value = result.Properties["displayname"][0].ToString();
                }
                
                // (result.Properties["displayname"][0].ToString());
            }


            this.Text = "AdminRDP";

        }

        private void button2_Click(object sender, EventArgs e)
           
        {
            if (dataGridView1.Visible == false)
            {
                MessageBox.Show("Заполните список");
            }
            else
                //получение имени Сервера
            GName = comboBox1.Text;  //server
            string cb = comboBox1.Text.ToString();
           // MessageBox.Show(cb);

            //получение id пользователя
            string id = dataGridView1.CurrentCell.RowIndex.ToString(); //выделен  ячейка
             int idi =   Convert.ToInt32(id);
            //idi = idi;
            //MessageBox.Show(idi.ToString());
            string cell1 = (dataGridView1.Rows[idi].Cells[2]).Value.ToString();  //обратиться к ячейки,  получить id сеанса 
                                                                                 //MessageBox.Show(cell1);

            //****************проверка ChekBox*****************
            if (checkBox1.Checked == true)
            {
                // MessageBox.Show("Флажок " + checkBox1.Text + "  теперь отмечен");

                //**************запуск mstsc с параметрами**************
                Process iStartProcess = new Process();
                iStartProcess.StartInfo.FileName = Environment.ExpandEnvironmentVariables(@"%systemroot%\SysWOW64\mstsc.exe");
                iStartProcess.StartInfo.Arguments = " mstsc /v:" + cb + " /shadow:" + cell1 + " /control";
                iStartProcess.StartInfo.WindowStyle = ProcessWindowStyle.Normal;
                iStartProcess.Start();
                //iStartProcess.WaitForExit(120000); 

            }
            else
            {
                //MessageBox.Show("Флажок " + checkBox1.Text + "  теперь не отмечен");

                //**************запуск mstsc с параметрами**************
                Process iStartProcess = new Process();
                iStartProcess.StartInfo.FileName = Environment.ExpandEnvironmentVariables(@"%systemroot%\SysWOW64\mstsc.exe");
                iStartProcess.StartInfo.Arguments = " mstsc /v:" + cb + " /shadow:" + cell1 + " /noconsentprompt";
                iStartProcess.StartInfo.WindowStyle = ProcessWindowStyle.Normal;
                iStartProcess.Start();
                //iStartProcess.WaitForExit(120000); 
            }




        }

        private void dataGridView1_Click(object sender, DataGridViewCellEventArgs e)
        {
            
            //выделение строки
            int index = dataGridView1.CurrentRow.Index;
            dataGridView1.Rows[index].Selected = true;
            // MessageBox.Show(dataGridView1.Rows[index].ToString());


        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }


    }
    

}

      
    


